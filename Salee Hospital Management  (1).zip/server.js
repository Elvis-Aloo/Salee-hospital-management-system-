const express = require('express');
const mysql = require('mysql2');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
    secret: 'salee_secret',
    resave: false,
    saveUninitialized: true
}));

app.use(express.static(path.join(__dirname, '../public')));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'salee_hms'
});

// Login API
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    db.query(
        'SELECT * FROM users WHERE username=? AND password=?',
        [username, password],
        (err, results) => {
            if (results.length > 0) {
                req.session.user = results[0];
                res.json({ success: true });
            } else {
                res.json({ success: false, message: 'Invalid credentials' });
            }
        }
    );
});

// Dashboard check
app.get('/api/user', (req, res) => {
    if (req.session.user) {
        res.json({ loggedIn: true, user: req.session.user });
    } else {
        res.json({ loggedIn: false });
    }
});

app.listen(3000, () => console.log('✅ Server running on http://localhost:3000'));
