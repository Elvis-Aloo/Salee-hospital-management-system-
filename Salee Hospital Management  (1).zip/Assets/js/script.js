// ======= USER AUTH HANDLING =======

// Save user to localStorage during registration
function registerUser(username, password){
  let users = JSON.parse(localStorage.getItem('users')) || [];
  const exists = users.find(u => u.username === username);

  if(exists){
    alert("⚠️ Username already exists. Try a different one.");
    return false;
  }

  users.push({username, password});
  localStorage.setItem('users', JSON.stringify(users));
  alert("✅ Registration successful! You can now login.");
  window.location.href = "login.html";
  return true;
}

// Login user
function loginUser(username, password){
  let users = JSON.parse(localStorage.getItem('users')) || [];
  const validUser = users.find(u => u.username === username && u.password === password);

  if(validUser){
    localStorage.setItem('isLoggedIn', 'true');
    localStorage.setItem('loggedInUser', username);
    alert("✅ Login Successful!");
    window.location.href = "dashboard.html";
  } else {
    document.getElementById('errorMsg').innerText = "❌ Invalid Username or Password!";
  }
}

// Logout user
function logout(){
  localStorage.removeItem('isLoggedIn');
  localStorage.removeItem('loggedInUser');
  alert("✅ You have been logged out!");
  window.location.href = "index.html";
}

// ======= PAGE-SPECIFIC CODE =======
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');

  // Handle login form submit
  if(loginForm){
    loginForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const username = document.getElementById('username').value.trim();
      const password = document.getElementById('password').value.trim();
      loginUser(username, password);
    });
  }

  // Handle register form submit
  if(registerForm){
    registerForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const username = document.getElementById('regUsername').value.trim();
      const password = document.getElementById('regPassword').value.trim();
      registerUser(username, password);
    });
  }

  // Dashboard Protection
  if(window.location.pathname.includes("dashboard.html")){
    if(localStorage.getItem('isLoggedIn') !== 'true'){
      alert("⚠️ Please login first!");
      window.location.href = "login.html";
    } else {
      const user = localStorage.getItem('loggedInUser');
      if(document.getElementById('welcomeUser')){
        document.getElementById('welcomeUser').innerText = "Welcome, " + user;
      }
    }
  }
});
