document.addEventListener('DOMContentLoaded', async function() {
  // Load patients
  const patients = await mockAPI.getPatients();
  const patientSelect = document.getElementById('patientSelect');
  
  patientSelect.innerHTML = patients.map(p => 
    `<option value="${p.id}">${p.name} (${p.gender})</option>`
  ).join('');

  // Add medication row
  document.getElementById('addMedication').addEventListener('click', async function() {
    const medications = await mockAPI.getMedications();
    const container = document.getElementById('medicationEntries');
    
    const div = document.createElement('div');
    div.className = 'medication-row row mb-3';
    div.innerHTML = `
      <div class="col-md-5">
        <select class="form-control" name="medication" required>
          <option value="">Select Medication</option>
          ${medications.map(m => `
            <option value="${m.id}" data-stock="${m.stock}">
              ${m.name} (${m.dosage}) - Stock: ${m.stock}
            </option>
          `).join('')}
        </select>
      </div>
      <div class="col-md-2">
        <input type="text" class="form-control" name="dosage" placeholder="Dosage" required>
      </div>
      <div class="col-md-2">
        <input type="text" class="form-control" name="frequency" placeholder="Frequency" required>
      </div>
      <div class="col-md-2">
        <input type="text" class="form-control" name="duration" placeholder="Duration" required>
      </div>
      <div class="col-md-1">
        <button type="button" class="btn btn-danger remove-btn">×</button>
      </div>
    `;
    
    container.appendChild(div);
    
    // Add remove functionality
    div.querySelector('.remove-btn').addEventListener('click', function() {
      container.removeChild(div);
    });
  });

  // Form submission
  document.getElementById('prescriptionForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
      patientId: document.getElementById('patientSelect').value,
      medications: Array.from(document.querySelectorAll('.medication-row')).map(row => ({
        medicationId: row.querySelector('[name="medication"]').value,
        dosage: row.querySelector('[name="dosage"]').value,
        frequency: row.querySelector('[name="frequency"]').value,
        duration: row.querySelector('[name="duration"]').value
      }))
    };
    
    const result = await mockAPI.submitPrescription(formData);
    alert(`Prescription ${result.prescriptionId} saved successfully!`);
  });
});