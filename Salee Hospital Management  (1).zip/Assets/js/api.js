// Mock API endpoints
const mockAPI = {
  getPatients: async () => {
    return [
      { id: "P001", name: "John Doe", gender: "Male" },
      { id: "P002", name: "Jane Smith", gender: "Female" }
    ];
  },

  getMedications: async () => {
    return [
      { id: "MED001", name: "Paracetamol", dosage: "500mg", stock: 100 },
      { id: "MED002", name: "Amoxicillin", dosage: "250mg", stock: 50 }
    ];
  },

  submitPrescription: async (data) => {
    console.log("Mock submission:", data);
    return { success: true, prescriptionId: "RX" + Math.random().toString(36).substr(2, 9) };
  }
};

// Real API would look like this:
/*
const realAPI = {
  getPatients: async () => {
    const response = await fetch('/api/patients');
    return response.json();
  }
};
*/