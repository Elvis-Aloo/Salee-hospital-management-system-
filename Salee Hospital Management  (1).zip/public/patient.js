const API_URL = '/api/patients';

// Age calculation
function calculateAge(dob) {
  const birth = new Date(dob);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
  return age;
}

// Load patients from backend
async function loadPatients() {
  const res = await fetch(API_URL);
  const patients = await res.json();

  const searchTerm = document.getElementById("searchInput").value.toLowerCase();
  const filterType = document.getElementById("filterSelect").value;

  const filtered = patients.filter(p => {
    const matchName = p.name.toLowerCase().includes(searchTerm);
    const matchFilter = filterType === "all" ||
      (filterType === "adults" && p.age >= 18) ||
      (filterType === "children" && p.age < 18);
    return matchName && matchFilter;
  });

  const table = document.getElementById("patientTable");
  table.innerHTML = filtered.map(p => `
    <tr>
      <td>${p.id}</td>
      <td>${p.name}</td>
      <td>${p.dob}</td>
      <td>${p.age}</td>
      <td>${p.gender}</td>
      <td>${p.guardian || "-"}</td>
      <td>
        <button class="btn btn-warning btn-sm" onclick="openEdit(${p.id})">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deletePatient(${p.id})">Delete</button>
      </td>
    </tr>
  `).join("");
}

// Add new patient
document.getElementById("addPatientForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  const ageVal = calculateAge(pDob.value);

  if (ageVal < 18 && (gName.value.trim() === "" || gContact.value.trim() === "")) {
    alert("Guardian Name and Contact are required for patients under 18.");
    return;
  }

  const newPatient = {
    name: pName.value,
    dob: pDob.value,
    age: ageVal,
    gender: pGender.value,
    guardian: ageVal < 18 ? (gName.value + " (" + gContact.value + ")") : null
  };

  await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(newPatient)
  });

  this.reset();
  guardianFields.forEach(el => el.style.display = "none");
  loadPatients();
});

// Delete patient
async function deletePatient(id) {
  await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
  loadPatients();
}

// Open Edit Modal
async function openEdit(id) {
  const res = await fetch(API_URL);
  const patients = await res.json();
  const patient = patients.find(p => p.id === id);

  document.getElementById("editId").value = patient.id;
  document.getElementById("editName").value = patient.name;
  document.getElementById("editDob").value = patient.dob;
  document.getElementById("editGender").value = patient.gender;
  document.getElementById("editGuardian").value = patient.guardian || "";
  document.getElementById("editModal").style.display = "flex";
}

// Save edit
async function saveEdit() {
  const id = document.getElementById("editId").value;
  const dob = document.getElementById("editDob").value;
  const updated = {
    name: document.getElementById("editName").value,
    dob: dob,
    age: calculateAge(dob),
    gender: document.getElementById("editGender").value,
    guardian: document.getElementById("editGuardian").value || null
  };

  await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updated)
  });

  closeEdit();
  loadPatients();
}

function closeEdit() {
  document.getElementById("editModal").style.display = "none";
}

// Guardian display logic
const pDob = document.getElementById("pDob");
const guardianFields = document.querySelectorAll(".guardian-section");
pDob.addEventListener("change", function () {
  const age = calculateAge(pDob.value);
  guardianFields.forEach(el => el.style.display = age < 18 ? "block" : "none");
});

// Search & Filter events
document.getElementById("searchInput").addEventListener("input", loadPatients);
document.getElementById("filterSelect").addEventListener("change", loadPatients);

// Initial load
loadPatients();
