<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'salee_hms');

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $query = $conn->prepare("SELECT * FROM users WHERE username=? AND password=?");
    $query->bind_param("ss", $username, $password);
    $query->execute();
    $result = $query->get_result();

    if($result->num_rows > 0){
        $_SESSION['user'] = $username;
        header("Location: dashboard.html");
        exit();
    } else {
        echo "<script>alert('Invalid login'); window.location='login.html';</script>";
    }
}
?>
