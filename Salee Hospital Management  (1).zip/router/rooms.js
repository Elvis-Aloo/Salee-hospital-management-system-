const express = require('express');
const router = express.Router();
const db = require('../models/db');

router.get('/', (req, res) => {
  db.query('SELECT * FROM rooms', (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

router.post('/', (req, res) => {
  const { room_number, type } = req.body;
  db.query('INSERT INTO rooms (room_number, type) VALUES (?,?)', 
    [room_number, type], (err, result) => {
      if (err) throw err;
      res.json({ message: 'Room added', id: result.insertId });
  });
});

router.put('/:id', (req, res) => {
  const { status } = req.body;
  db.query('UPDATE rooms SET status=? WHERE id=?', 
    [status, req.params.id], err => {
      if (err) throw err;
      res.json({ message: 'Room status updated' });
  });
});

router.delete('/:id', (req, res) => {
  db.query('DELETE FROM rooms WHERE id=?', [req.params.id], err => {
    if (err) throw err;
    res.json({ message: 'Room deleted' });
  });
});

module.exports = router;
