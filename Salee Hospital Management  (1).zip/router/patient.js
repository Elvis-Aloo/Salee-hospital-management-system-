// LocalStorage Database Helper
const DB = {
  get: key => JSON.parse(localStorage.getItem(key) || '[]'),
  set: (key, data) => localStorage.setItem(key, JSON.stringify(data)),
  add: (key, obj) => { const data = DB.get(key); data.push(obj); DB.set(key, data); },
  update: (key, id, newData) => {
    const data = DB.get(key).map(p => p.id === id ? { ...p, ...newData } : p);
    DB.set(key, data);
  },
  delete: (key, id) => { DB.set(key, DB.get(key).filter(p => p.id !== id)); }
};

// DOM Elements
const pDob = document.getElementById("pDob");
const guardianFields = document.querySelectorAll(".guardian-section");

// Age Calculation
function calculateAge(dob) {
  const birth = new Date(dob);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
  return age;
}

// Show guardian fields for children
pDob.addEventListener("change", function () {
  const age = calculateAge(pDob.value);
  guardianFields.forEach(el => el.style.display = age < 18 ? "block" : "none");
});

// Load Patients into Table
function loadPatients() {
  const patients = DB.get("patients");
  const searchTerm = document.getElementById("searchInput").value.toLowerCase();
  const filterType = document.getElementById("filterSelect").value;

  const filtered = patients.filter(p => {
    const matchName = p.name.toLowerCase().includes(searchTerm);
    const matchFilter = filterType === "all" ||
      (filterType === "adults" && p.age >= 18) ||
      (filterType === "children" && p.age < 18);
    return matchName && matchFilter;
  });

  const table = document.getElementById("patientTable");
  table.innerHTML = filtered.map(p => `
    <tr>
      <td>${p.id}</td>
      <td>${p.name}</td>
      <td>${p.dob}</td>
      <td>${p.age}</td>
      <td>${p.gender}</td>
      <td>${p.guardian || "-"}</td>
      <td>
        <button class="btn btn-warning btn-sm" onclick="openEdit('${p.id}')">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deletePatient('${p.id}')">Delete</button>
      </td>
    </tr>
  `).join("");
}

// Add Patient
document.getElementById("addPatientForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const ageVal = calculateAge(pDob.value);

  if (ageVal < 18 && (gName.value.trim() === "" || gContact.value.trim() === "")) {
    alert("Guardian Name and Contact are required for patients under 18.");
    return;
  }

  const newID = ageVal < 18 ? "CHILD-" + Date.now() : "P-" + Date.now();

  DB.add("patients", {
    id: newID,
    name: pName.value,
    dob: pDob.value,
    age: ageVal,
    gender: pGender.value,
    guardian: ageVal < 18 ? (gName.value + " (" + gContact.value + ")") : null
  });

  this.reset();
  guardianFields.forEach(el => el.style.display = "none");
  loadPatients();
});

// Delete Patient
function deletePatient(id) {
  DB.delete("patients", id);
  loadPatients();
}

// Open Edit Modal
function openEdit(id) {
  const patient = DB.get("patients").find(p => p.id === id);
  document.getElementById("editId").value = patient.id;
  document.getElementById("editName").value = patient.name;
  document.getElementById("editDob").value = patient.dob;
  document.getElementById("editGender").value = patient.gender;
  document.getElementById("editGuardian").value = patient.guardian || "";
  document.getElementById("editModal").style.display = "flex";
}

// Close Edit Modal
function closeEdit() {
  document.getElementById("editModal").style.display = "none";
}

// Save Edited Patient
function saveEdit() {
  const id = document.getElementById("editId").value;
  const dob = document.getElementById("editDob").value;
  const updated = {
    name: document.getElementById("editName").value,
    dob: dob,
    age: calculateAge(dob),
    gender: document.getElementById("editGender").value,
    guardian: document.getElementById("editGuardian").value || null
  };
  DB.update("patients", id, updated);
  closeEdit();
  loadPatients();
}

// Search and Filter
document.getElementById("searchInput").addEventListener("input", loadPatients);
document.getElementById("filterSelect").addEventListener("change", loadPatients);

// Sample Patients
if (DB.get("patients").length === 0) {
  const sample = [
    { id: "P-1001", name: "John Doe", dob: "1990-05-12", age: 35, gender: "Male" },
    { id: "P-1002", name: "Mary Wanjiru", dob: "1998-09-25", age: 27, gender: "Female" },
    { id: "CHILD-1003", name: "Brian Onyango", dob: "2012-03-14", age: 13, gender: "Male", guardian: "James Onyango (0712345678)" }
  ];
  sample.forEach(p => DB.add("patients", p));
}

// Initial Load
loadPatients();
