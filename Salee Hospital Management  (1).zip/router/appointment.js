const express = require('express');
const router = express.Router();
const db = require('../models/db');

router.get('/', (req, res) => {
  db.query(`
    SELECT a.id, p.name AS patient, d.name AS doctor, a.date, a.status
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN doctors d ON a.doctor_id = d.id
  `, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

router.post('/', (req, res) => {
  const { patient_id, doctor_id, date } = req.body;
  db.query('INSERT INTO appointments (patient_id, doctor_id, date) VALUES (?,?,?)', 
    [patient_id, doctor_id, date], (err, result) => {
      if (err) throw err;
      res.json({ message: 'Appointment scheduled', id: result.insertId });
  });
});

router.put('/:id', (req, res) => {
  const { status } = req.body;
  db.query('UPDATE appointments SET status=? WHERE id=?', 
    [status, req.params.id], err => {
      if (err) throw err;
      res.json({ message: 'Appointment updated' });
  });
});

router.delete('/:id', (req, res) => {
  db.query('DELETE FROM appointments WHERE id=?', [req.params.id], err => {
    if (err) throw err;
    res.json({ message: 'Appointment deleted' });
  });
});

module.exports = router;
