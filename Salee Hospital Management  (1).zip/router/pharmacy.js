const express = require('express');
const router = express.Router();
const db = require('../models/db');

router.get('/', (req, res) => {
  db.query('SELECT * FROM pharmacy', (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

router.post('/', (req, res) => {
  const { medicine_name, stock, price } = req.body;
  db.query('INSERT INTO pharmacy (medicine_name, stock, price) VALUES (?,?,?)', 
    [medicine_name, stock, price], (err, result) => {
      if (err) throw err;
      res.json({ message: 'Medicine added', id: result.insertId });
  });
});

router.put('/:id', (req, res) => {
  const { medicine_name, stock, price } = req.body;
  db.query('UPDATE pharmacy SET medicine_name=?, stock=?, price=? WHERE id=?', 
    [medicine_name, stock, price, req.params.id], err => {
      if (err) throw err;
      res.json({ message: 'Medicine updated' });
  });
});

router.delete('/:id', (req, res) => {
  db.query('DELETE FROM pharmacy WHERE id=?', [req.params.id], err => {
    if (err) throw err;
    res.json({ message: 'Medicine deleted' });
  });
});

module.exports = router;
