// appointments.handlers.js - Manages Appointments

function getAppointments() {
    return JSON.parse(localStorage.getItem('appointments') || '[]');
}

function saveAppointments(appointments) {
    localStorage.setItem('appointments', JSON.stringify(appointments));
}

function addAppointment(app) {
    const appointments = getAppointments();
    appointments.push(app);
    saveAppointments(appointments);
}

function updateAppointment(id, updated) {
    let appointments = getAppointments();
    appointments = appointments.map(a => a.id === id ? { ...a, ...updated } : a);
    saveAppointments(appointments);
}

function deleteAppointment(id) {
    let appointments = getAppointments();
    appointments = appointments.filter(a => a.id !== id);
    saveAppointments(appointments);
}
