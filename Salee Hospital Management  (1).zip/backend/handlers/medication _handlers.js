// medications.handlers.js - Manages Medications

function getMedications() {
    return JSON.parse(localStorage.getItem('medications') || '[]');
}

function saveMedications(meds) {
    localStorage.setItem('medications', JSON.stringify(meds));
}

function addMedication(med) {
    const meds = getMedications();
    meds.push(med);
    saveMedications(meds);
}

function updateMedication(id, updated) {
    let meds = getMedications();
    meds = meds.map(m => m.id === id ? { ...m, ...updated } : m);
    saveMedications(meds);
}

function deleteMedication(id) {
    let meds = getMedications();
    meds = meds.filter(m => m.id !== id);
    saveMedications(meds);
}
