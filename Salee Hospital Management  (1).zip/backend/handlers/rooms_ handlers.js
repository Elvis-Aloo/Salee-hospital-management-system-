// rooms.handlers.js - Manages Rooms & Departments

function getRooms() {
    return JSON.parse(localStorage.getItem('rooms') || '[]');
}

function saveRooms(rooms) {
    localStorage.setItem('rooms', JSON.stringify(rooms));
}

function addRoom(room) {
    const rooms = getRooms();
    rooms.push(room);
    saveRooms(rooms);
}

function updateRoom(id, updated) {
    let rooms = getRooms();
    rooms = rooms.map(r => r.roomId === id ? { ...r, ...updated } : r);
    saveRooms(rooms);
}

function deleteRoom(id) {
    let rooms = getRooms();
    rooms = rooms.filter(r => r.roomId !== id);
    saveRooms(rooms);
}

function getDepartments() {
    return JSON.parse(localStorage.getItem('departments') || '[]');
}

function saveDepartments(departments) {
    localStorage.setItem('departments', JSON.stringify(departments));
}
