// ================= AUTH HANDLERS =================
function getUsers() {
    return JSON.parse(localStorage.getItem('users') || '[]');
}
function saveUsers(users) {
    localStorage.setItem('users', JSON.stringify(users));
}
function registerUser(username, password) {
    const users = getUsers();
    if (users.find(u => u.username === username)) return { success: false, message: "Username exists" };
    users.push({ username, password });
    saveUsers(users);
    return { success: true };
}
function loginUser(username, password) {
    const users = getUsers();
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        localStorage.setItem('isLoggedIn', 'true');
        return { success: true };
    }
    return { success: false, message: "Invalid login" };
}
function logoutUser() {
    localStorage.removeItem('isLoggedIn');
}

// ================= PATIENTS HANDLERS =================
function getPatients() {
    return JSON.parse(localStorage.getItem('patients') || '[]');
}
function savePatients(patients) {
    localStorage.setItem('patients', JSON.stringify(patients));
}
function addPatient(patient) {
    const patients = getPatients();
    patients.push(patient);
    savePatients(patients);
}
function updatePatient(id, updated) {
    let patients = getPatients();
    patients = patients.map(p => p.id === id ? { ...p, ...updated } : p);
    savePatients(patients);
}
function deletePatient(id) {
    let patients = getPatients();
    patients = patients.filter(p => p.id !== id);
    savePatients(patients);
}
function calcAge(dob) {
    const birth = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    return age;
}

// ================= DOCTORS HANDLERS =================
function getDoctors() {
    return JSON.parse(localStorage.getItem('doctors') || '[]');
}
function saveDoctors(doctors) {
    localStorage.setItem('doctors', JSON.stringify(doctors));
}
function addDoctor(doctor) {
    const doctors = getDoctors();
    doctors.push(doctor);
    saveDoctors(doctors);
}
function updateDoctor(id, updated) {
    let doctors = getDoctors();
    doctors = doctors.map(d => d.id === id ? { ...d, ...updated } : d);
    saveDoctors(doctors);
}
function deleteDoctor(id) {
    let doctors = getDoctors();
    doctors = doctors.filter(d => d.id !== id);
    saveDoctors(doctors);
}

// ================= BILLING HANDLERS =================
function getInvoices() {
    return JSON.parse(localStorage.getItem('billing') || '[]');
}
function saveInvoices(invoices) {
    localStorage.setItem('billing', JSON.stringify(invoices));
}
function addInvoice(invoice) {
    const invoices = getInvoices();
    invoices.push(invoice);
    saveInvoices(invoices);
}
function calculateTotals() {
    const invoices = getInvoices();
    let totalRevenue = 0, totalPending = 0;
    invoices.forEach(inv => {
        if (inv.status === "Paid") totalRevenue += inv.amount;
        else totalPending += inv.amount;
    });
    return { totalRevenue, totalPending };
}
function updateInvoiceStatus(id, status) {
    let invoices = getInvoices();
    invoices = invoices.map(inv => inv.invoiceId === id ? { ...inv, status } : inv);
    saveInvoices(invoices);
}

// ================= ROOMS & DEPARTMENTS =================
function getRooms() {
    return JSON.parse(localStorage.getItem('rooms') || '[]');
}
function saveRooms(rooms) {
    localStorage.setItem('rooms', JSON.stringify(rooms));
}
function addRoom(room) {
    const rooms = getRooms();
    rooms.push(room);
    saveRooms(rooms);
}
function updateRoom(id, updated) {
    let rooms = getRooms();
    rooms = rooms.map(r => r.roomId === id ? { ...r, ...updated } : r);
    saveRooms(rooms);
}
function deleteRoom(id) {
    let rooms = getRooms();
    rooms = rooms.filter(r => r.roomId !== id);
    saveRooms(rooms);
}

function getDepartments() {
    return JSON.parse(localStorage.getItem('departments') || '[]');
}
function saveDepartments(departments) {
    localStorage.setItem('departments', JSON.stringify(departments));
}

// ================= APPOINTMENTS =================
function getAppointments() {
    return JSON.parse(localStorage.getItem('appointments') || '[]');
}
function saveAppointments(appointments) {
    localStorage.setItem('appointments', JSON.stringify(appointments));
}
function addAppointment(app) {
    const appointments = getAppointments();
    appointments.push(app);
    saveAppointments(appointments);
}
function updateAppointment(id, updated) {
    let appointments = getAppointments();
    appointments = appointments.map(a => a.id === id ? { ...a, ...updated } : a);
    saveAppointments(appointments);
}
function deleteAppointment(id) {
    let appointments = getAppointments();
    appointments = appointments.filter(a => a.id !== id);
    saveAppointments(appointments);
}

// ================= INVENTORY =================
function getInventory() {
    return JSON.parse(localStorage.getItem('inventory') || '[]');
}
function saveInventory(items) {
    localStorage.setItem('inventory', JSON.stringify(items));
}
function addInventoryItem(item) {
    const items = getInventory();
    items.push(item);
    saveInventory(items);
}
function updateInventoryItem(id, updated) {
    let items = getInventory();
    items = items.map(i => i.id === id ? { ...i, ...updated } : i);
    saveInventory(items);
}
function deleteInventoryItem(id) {
    let items = getInventory();
    items = items.filter(i => i.id !== id);
    saveInventory(items);
}

// ================= MEDICATIONS =================
function getMedications() {
    return JSON.parse(localStorage.getItem('medications') || '[]');
}
function saveMedications(meds) {
    localStorage.setItem('medications', JSON.stringify(meds));
}
function addMedication(med) {
    const meds = getMedications();
    meds.push(med);
    saveMedications(meds);
}
function updateMedication(id, updated) {
    let meds = getMedications();
    meds = meds.map(m => m.id === id ? { ...m, ...updated } : m);
    saveMedications(meds);
}
function deleteMedication(id) {
    let meds = getMedications();
    meds = meds.filter(m => m.id !== id);
    saveMedications(meds);
}
