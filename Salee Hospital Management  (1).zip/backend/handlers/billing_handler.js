// billing.handlers.js - Manages Billing & Invoices

function getInvoices() {
    return JSON.parse(localStorage.getItem('billing') || '[]');
}

function saveInvoices(invoices) {
    localStorage.setItem('billing', JSON.stringify(invoices));
}

function addInvoice(invoice) {
    const invoices = getInvoices();
    invoices.push(invoice);
    saveInvoices(invoices);
}

function calculateTotals() {
    const invoices = getInvoices();
    let totalRevenue = 0, totalPending = 0;
    invoices.forEach(inv => {
        if (inv.status === "Paid") totalRevenue += inv.amount;
        else totalPending += inv.amount;
    });
    return { totalRevenue, totalPending };
}

function updateInvoiceStatus(id, status) {
    let invoices = getInvoices();
    invoices = invoices.map(inv => inv.invoiceId === id ? { ...inv, status } : inv);
    saveInvoices(invoices);
}
