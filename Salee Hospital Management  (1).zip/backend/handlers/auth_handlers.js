// auth.handlers.js - Manages Login & Registration

function getUsers() {
    return JSON.parse(localStorage.getItem('users') || '[]');
}

function saveUsers(users) {
    localStorage.setItem('users', JSON.stringify(users));
}

// Register new user
function registerUser(username, password) {
    const users = getUsers();
    if (users.find(u => u.username === username)) {
        return { success: false, message: "Username already exists" };
    }
    users.push({ username, password });
    saveUsers(users);
    return { success: true };
}

// Login user
function loginUser(username, password) {
    const users = getUsers();
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        localStorage.setItem('isLoggedIn', 'true');
        return { success: true };
    }
    return { success: false, message: "Invalid username or password" };
}

// Logout
function logoutUser() {
    localStorage.removeItem('isLoggedIn');
}
