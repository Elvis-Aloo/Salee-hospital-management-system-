// inventory.handlers.js - Manages Inventory & Stock

function getInventory() {
    return JSON.parse(localStorage.getItem('inventory') || '[]');
}

function saveInventory(items) {
    localStorage.setItem('inventory', JSON.stringify(items));
}

function addInventoryItem(item) {
    const items = getInventory();
    items.push(item);
    saveInventory(items);
}

function updateInventoryItem(id, updated) {
    let items = getInventory();
    items = items.map(i => i.id === id ? { ...i, ...updated } : i);
    saveInventory(items);
}

function deleteInventoryItem(id) {
    let items = getInventory();
    items = items.filter(i => i.id !== id);
    saveInventory(items);
}
