// patients.handlers.js - Manages Patients Data

function getPatients() {
    return JSON.parse(localStorage.getItem('patients') || '[]');
}

function savePatients(patients) {
    localStorage.setItem('patients', JSON.stringify(patients));
}

function addPatient(patient) {
    const patients = getPatients();
    patients.push(patient);
    savePatients(patients);
}

function updatePatient(id, updated) {
    let patients = getPatients();
    patients = patients.map(p => p.id === id ? { ...p, ...updated } : p);
    savePatients(patients);
}

function deletePatient(id) {
    let patients = getPatients();
    patients = patients.filter(p => p.id !== id);
    savePatients(patients);
}

function calcAge(dob) {
    const birth = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    return age;
}
