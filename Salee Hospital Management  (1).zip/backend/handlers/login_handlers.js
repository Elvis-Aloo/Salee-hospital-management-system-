// Register (Auto-login after registration)
document.getElementById("registerForm").addEventListener("submit", function(e){
  e.preventDefault();
  const email = document.getElementById("registerEmail").value.trim();
  const password = document.getElementById("registerPassword").value.trim();
  const registerMsg = document.getElementById("registerMsg");

  let users = JSON.parse(localStorage.getItem("users") || "[]");
  if(users.find(user => user.email === email)) {
    registerMsg.style.display = "block";
    registerMsg.className = "alert alert-warning";
    registerMsg.innerText = "User already exists!";
  } else {
    users.push({ email, password });
    localStorage.setItem("users", JSON.stringify(users));

    //  Auto-login
    localStorage.setItem("loggedIn", "true");
    window.location.href = "dashboard.html"; // Redirect to dashboard immediately
  }
});
