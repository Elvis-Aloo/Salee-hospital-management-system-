// doctors.handlers.js - Manages Doctors Data

function getDoctors() {
    return JSON.parse(localStorage.getItem('doctors') || '[]');
}

function saveDoctors(doctors) {
    localStorage.setItem('doctors', JSON.stringify(doctors));
}

function addDoctor(doctor) {
    const doctors = getDoctors();
    doctors.push(doctor);
    saveDoctors(doctors);
}

function updateDoctor(id, updated) {
    let doctors = getDoctors();
    doctors = doctors.map(d => d.id === id ? { ...d, ...updated } : d);
    saveDoctors(doctors);
}

function deleteDoctor(id) {
    let doctors = getDoctors();
    doctors = doctors.filter(d => d.id !== id);
    saveDoctors(doctors);
}
