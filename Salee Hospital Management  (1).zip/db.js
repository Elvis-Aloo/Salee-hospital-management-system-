const DB = {
  get: (key) => JSON.parse(localStorage.getItem(key) || "[]"),
  set: (key, data) => localStorage.setItem(key, JSON.stringify(data)),
  add: (key, item) => {
    const data = DB.get(key);
    item.id = Date.now();
    data.push(item);
    DB.set(key, data);
  },
  delete: (key, id) => {
    const data = DB.get(key).filter(i => i.id !== id);
    DB.set(key, data);
  },
  find: (key, callback) => DB.get(key).find(callback)
};

// ✅ Create 10 sample patients if none exist
if (DB.get("patients").length === 0) {
  const samplePatients = [
    { name: "John Doe", age: 30, gender: "Male" },
    { name: "Mary Ann", age: 25, gender: "Female" },
    { name: "Peter Kim", age: 40, gender: "Male" },
    { name: "Susan Auma", age: 29, gender: "Female" },
    { name: "David Otieno", age: 35, gender: "Male" },
    { name: "Grace Wanjiru", age: 32, gender: "Female" },
    { name: "Brian Ouma", age: 45, gender: "Male" },
    { name: "Cynthia Moraa", age: 28, gender: "Female" },
    { name: "Kevin Odhiambo", age: 38, gender: "Male" },
    { name: "Alice Atieno", age: 27, gender: "Female" }
  ];
  samplePatients.forEach(p => DB.add("patients", p));
}

// ✅ Create 10 sample lab tests if none exist
if (DB.get("labTests").length === 0) {
  const sampleTests = [
    { testName: "Blood Test", cost: 1500 },
    { testName: "Urine Test", cost: 800 },
    { testName: "Malaria Test", cost: 1000 },
    { testName: "HIV Test", cost: 500 },
    { testName: "Covid-19 Test", cost: 2000 },
    { testName: "X-Ray", cost: 3000 },
    { testName: "CT Scan", cost: 5000 },
    { testName: "MRI", cost: 7000 },
    { testName: "Pregnancy Test", cost: 600 },
    { testName: "Liver Function Test", cost: 2500 }
  ];
  DB.set("labTests", sampleTests);
}

// ✅ Ensure prescriptions and labOrders arrays exist
if (!localStorage.getItem("prescriptions")) DB.set("prescriptions", []);
if (!localStorage.getItem("labOrders")) DB.set("labOrders", []);
